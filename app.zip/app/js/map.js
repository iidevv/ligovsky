// // Vars

// const mapSW = [0, 4096],
//   mapNE = [4096, 0];

// // refs tiles
// const map = L.map("map", {
//   zoomControl: false,
//   attributionControl: false,
// }).setView([0, 0], 2);

// L.tileLayer("map/{z}/{x}/{y}.png", {
//   minZoom: 1,
//   maxZoom: 4,
//   continuousWorld: false,
//   noWrap: true,
//   crs: L.CRS.Simple,
// }).addTo(map);

// map.setMaxBounds(
//   new L.LatLngBounds(
//     map.unproject(mapSW, map.getMaxZoom()),
//     map.unproject(mapNE, map.getMaxZoom())
//   )
// );

// // choose place

// var popup = L.popup();

// function onMapClick(e) {
//   popup
//     .setLatLng(e.latlng)
//     .setContent(
//       "<a target='_blank' href='/#'>Купить место</a> " + e.latlng.toString()
//     )
//     .openOn(map);
// }

// map.on("click", onMapClick);

// //logos

// let logo1 = L.imageOverlay(
//   "images/logos/02.jpg",
//   [
//     [20, -80],
//     [0.7, -34],
//   ],
//   {
//     opacity: 1,
//     interactive: true,
//     draggable: true,
//   }
// );

// // logo 1

// logo1
// .bindPopup('company description <a target="_blank" href="/#">Перейти</a>')
// .addTo(map)

(function (window) {
  function init(mapid) {
    var minZoom = 1.7;
    var maxZoom = 3;
    var img = [
      4096, // original width of image
      4096, // 3072 original height of image
    ];

    // create the map
    var map = L.map(mapid, {
      minZoom: minZoom,
      maxZoom: maxZoom,
      zoomControl: false,
      attributionControl: false,
      zoomSnap: 0.1,
    });

    // assign map and image dimensions
    var rc = new L.RasterCoords(map, img);

    // set the view on a marker ...
    map.setView(rc.unproject([1942, 2050]), 1.7);
    map.dragging.disable();

    // the tile layer containing the image generated with gdal2tiles --leaflet ...
    L.tileLayer("map/{z}/{x}/{y}.png", {
      noWrap: true,
    }).addTo(map);

    // choose place

    var popup = L.popup();

    function onMapClick(e) {
      var coord = rc.project(e.latlng);

      popup
        .setLatLng(e.latlng)
        .setContent("[" + e.latlng + "]")
        .openOn(map);
    }
    map.on("click", onMapClick);

    // //logos

    let logo1 = L.imageOverlay(
      "images/logos/02.jpg",
      [
        [53, -36],
        [41, 9],
      ],
      {
        opacity: 1,
        interactive: true,
        draggable: true,
        className: "logo1",
        alt: "company description",
      }
    )
      .bindPopup('company description <a target="_blank" href="/#">Перейти</a>')
      .addTo(map);

    let logo2 = L.imageOverlay(
      "images/logos/03.jpg",
      [
        [53, 9],
        [26, 72],
      ],
      {
        opacity: 1,
        interactive: true,
        draggable: true,
        className: "logo1",
        alt: "company description2",
      }
    )
      .bindPopup(
        'company description2 <a target="_blank" href="/#">Перейти</a>'
      )
      .addTo(map);

    let logo3 = L.imageOverlay(
      "images/logos/02.jpg",
      [
        [66.5, -36],
        [53, 81],
      ],
      {
        opacity: 1,
        interactive: true,
        draggable: true,
        className: "logo1",
        alt: "company description3",
      }
    )
      .bindPopup(
        'company description3 <a target="_blank" href="/#">Перейти</a>'
      )
      .addTo(map);

    let logo4 = L.imageOverlay(
      "images/logos/04.jpg",
      [
        [41, -36],
        [34, -27],
      ],
      {
        opacity: 1,
        interactive: true,
        draggable: true,
        className: "logo1",
        alt: "company description4",
      }
    )
      .bindPopup(
        'company description4 <a target="_blank" href="/#">Перейти</a>'
      )
      .addTo(map);
  }

  init("map");
})(window);
